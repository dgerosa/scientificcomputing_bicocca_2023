# This file makes the directory a package
from .TicTacToe_2Players import TicTacToe